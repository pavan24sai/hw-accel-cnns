// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.2.2 (64-bit)
// Tool Version Limit: 2024.02
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xfashion_mnist_cnn_accelerator.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XFashion_mnist_cnn_accelerator_CfgInitialize(XFashion_mnist_cnn_accelerator *InstancePtr, XFashion_mnist_cnn_accelerator_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_r_BaseAddress = ConfigPtr->Control_r_BaseAddress;
    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XFashion_mnist_cnn_accelerator_Start(XFashion_mnist_cnn_accelerator *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFashion_mnist_cnn_accelerator_ReadReg(InstancePtr->Control_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_ADDR_AP_CTRL) & 0x80;
    XFashion_mnist_cnn_accelerator_WriteReg(InstancePtr->Control_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XFashion_mnist_cnn_accelerator_IsDone(XFashion_mnist_cnn_accelerator *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFashion_mnist_cnn_accelerator_ReadReg(InstancePtr->Control_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XFashion_mnist_cnn_accelerator_IsIdle(XFashion_mnist_cnn_accelerator *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFashion_mnist_cnn_accelerator_ReadReg(InstancePtr->Control_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XFashion_mnist_cnn_accelerator_IsReady(XFashion_mnist_cnn_accelerator *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFashion_mnist_cnn_accelerator_ReadReg(InstancePtr->Control_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XFashion_mnist_cnn_accelerator_EnableAutoRestart(XFashion_mnist_cnn_accelerator *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFashion_mnist_cnn_accelerator_WriteReg(InstancePtr->Control_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XFashion_mnist_cnn_accelerator_DisableAutoRestart(XFashion_mnist_cnn_accelerator *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFashion_mnist_cnn_accelerator_WriteReg(InstancePtr->Control_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_ADDR_AP_CTRL, 0);
}

void XFashion_mnist_cnn_accelerator_Set_input_ddr(XFashion_mnist_cnn_accelerator *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFashion_mnist_cnn_accelerator_WriteReg(InstancePtr->Control_r_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_R_ADDR_INPUT_DDR_DATA, (u32)(Data));
    XFashion_mnist_cnn_accelerator_WriteReg(InstancePtr->Control_r_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_R_ADDR_INPUT_DDR_DATA + 4, (u32)(Data >> 32));
}

u64 XFashion_mnist_cnn_accelerator_Get_input_ddr(XFashion_mnist_cnn_accelerator *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFashion_mnist_cnn_accelerator_ReadReg(InstancePtr->Control_r_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_R_ADDR_INPUT_DDR_DATA);
    Data += (u64)XFashion_mnist_cnn_accelerator_ReadReg(InstancePtr->Control_r_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_R_ADDR_INPUT_DDR_DATA + 4) << 32;
    return Data;
}

void XFashion_mnist_cnn_accelerator_Set_output_ddr(XFashion_mnist_cnn_accelerator *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFashion_mnist_cnn_accelerator_WriteReg(InstancePtr->Control_r_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_R_ADDR_OUTPUT_DDR_DATA, (u32)(Data));
    XFashion_mnist_cnn_accelerator_WriteReg(InstancePtr->Control_r_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_R_ADDR_OUTPUT_DDR_DATA + 4, (u32)(Data >> 32));
}

u64 XFashion_mnist_cnn_accelerator_Get_output_ddr(XFashion_mnist_cnn_accelerator *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFashion_mnist_cnn_accelerator_ReadReg(InstancePtr->Control_r_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_R_ADDR_OUTPUT_DDR_DATA);
    Data += (u64)XFashion_mnist_cnn_accelerator_ReadReg(InstancePtr->Control_r_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_R_ADDR_OUTPUT_DDR_DATA + 4) << 32;
    return Data;
}

void XFashion_mnist_cnn_accelerator_Set_weights_ddr(XFashion_mnist_cnn_accelerator *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFashion_mnist_cnn_accelerator_WriteReg(InstancePtr->Control_r_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_R_ADDR_WEIGHTS_DDR_DATA, (u32)(Data));
    XFashion_mnist_cnn_accelerator_WriteReg(InstancePtr->Control_r_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_R_ADDR_WEIGHTS_DDR_DATA + 4, (u32)(Data >> 32));
}

u64 XFashion_mnist_cnn_accelerator_Get_weights_ddr(XFashion_mnist_cnn_accelerator *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFashion_mnist_cnn_accelerator_ReadReg(InstancePtr->Control_r_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_R_ADDR_WEIGHTS_DDR_DATA);
    Data += (u64)XFashion_mnist_cnn_accelerator_ReadReg(InstancePtr->Control_r_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_R_ADDR_WEIGHTS_DDR_DATA + 4) << 32;
    return Data;
}

void XFashion_mnist_cnn_accelerator_Set_bias_ddr(XFashion_mnist_cnn_accelerator *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFashion_mnist_cnn_accelerator_WriteReg(InstancePtr->Control_r_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_R_ADDR_BIAS_DDR_DATA, (u32)(Data));
    XFashion_mnist_cnn_accelerator_WriteReg(InstancePtr->Control_r_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_R_ADDR_BIAS_DDR_DATA + 4, (u32)(Data >> 32));
}

u64 XFashion_mnist_cnn_accelerator_Get_bias_ddr(XFashion_mnist_cnn_accelerator *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFashion_mnist_cnn_accelerator_ReadReg(InstancePtr->Control_r_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_R_ADDR_BIAS_DDR_DATA);
    Data += (u64)XFashion_mnist_cnn_accelerator_ReadReg(InstancePtr->Control_r_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_R_ADDR_BIAS_DDR_DATA + 4) << 32;
    return Data;
}

void XFashion_mnist_cnn_accelerator_Set_layer_config(XFashion_mnist_cnn_accelerator *InstancePtr, XFashion_mnist_cnn_accelerator_Layer_config Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFashion_mnist_cnn_accelerator_WriteReg(InstancePtr->Control_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_ADDR_LAYER_CONFIG_DATA + 0, Data.word_0);
    XFashion_mnist_cnn_accelerator_WriteReg(InstancePtr->Control_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_ADDR_LAYER_CONFIG_DATA + 4, Data.word_1);
    XFashion_mnist_cnn_accelerator_WriteReg(InstancePtr->Control_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_ADDR_LAYER_CONFIG_DATA + 8, Data.word_2);
    XFashion_mnist_cnn_accelerator_WriteReg(InstancePtr->Control_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_ADDR_LAYER_CONFIG_DATA + 12, Data.word_3);
    XFashion_mnist_cnn_accelerator_WriteReg(InstancePtr->Control_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_ADDR_LAYER_CONFIG_DATA + 16, Data.word_4);
    XFashion_mnist_cnn_accelerator_WriteReg(InstancePtr->Control_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_ADDR_LAYER_CONFIG_DATA + 20, Data.word_5);
    XFashion_mnist_cnn_accelerator_WriteReg(InstancePtr->Control_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_ADDR_LAYER_CONFIG_DATA + 24, Data.word_6);
    XFashion_mnist_cnn_accelerator_WriteReg(InstancePtr->Control_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_ADDR_LAYER_CONFIG_DATA + 28, Data.word_7);
    XFashion_mnist_cnn_accelerator_WriteReg(InstancePtr->Control_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_ADDR_LAYER_CONFIG_DATA + 32, Data.word_8);
}

XFashion_mnist_cnn_accelerator_Layer_config XFashion_mnist_cnn_accelerator_Get_layer_config(XFashion_mnist_cnn_accelerator *InstancePtr) {
    XFashion_mnist_cnn_accelerator_Layer_config Data;

    Data.word_0 = XFashion_mnist_cnn_accelerator_ReadReg(InstancePtr->Control_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_ADDR_LAYER_CONFIG_DATA + 0);
    Data.word_1 = XFashion_mnist_cnn_accelerator_ReadReg(InstancePtr->Control_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_ADDR_LAYER_CONFIG_DATA + 4);
    Data.word_2 = XFashion_mnist_cnn_accelerator_ReadReg(InstancePtr->Control_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_ADDR_LAYER_CONFIG_DATA + 8);
    Data.word_3 = XFashion_mnist_cnn_accelerator_ReadReg(InstancePtr->Control_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_ADDR_LAYER_CONFIG_DATA + 12);
    Data.word_4 = XFashion_mnist_cnn_accelerator_ReadReg(InstancePtr->Control_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_ADDR_LAYER_CONFIG_DATA + 16);
    Data.word_5 = XFashion_mnist_cnn_accelerator_ReadReg(InstancePtr->Control_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_ADDR_LAYER_CONFIG_DATA + 20);
    Data.word_6 = XFashion_mnist_cnn_accelerator_ReadReg(InstancePtr->Control_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_ADDR_LAYER_CONFIG_DATA + 24);
    Data.word_7 = XFashion_mnist_cnn_accelerator_ReadReg(InstancePtr->Control_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_ADDR_LAYER_CONFIG_DATA + 28);
    Data.word_8 = XFashion_mnist_cnn_accelerator_ReadReg(InstancePtr->Control_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_ADDR_LAYER_CONFIG_DATA + 32);
    return Data;
}

void XFashion_mnist_cnn_accelerator_Set_layer_idx(XFashion_mnist_cnn_accelerator *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFashion_mnist_cnn_accelerator_WriteReg(InstancePtr->Control_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_ADDR_LAYER_IDX_DATA, Data);
}

u32 XFashion_mnist_cnn_accelerator_Get_layer_idx(XFashion_mnist_cnn_accelerator *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFashion_mnist_cnn_accelerator_ReadReg(InstancePtr->Control_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_ADDR_LAYER_IDX_DATA);
    return Data;
}

void XFashion_mnist_cnn_accelerator_InterruptGlobalEnable(XFashion_mnist_cnn_accelerator *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFashion_mnist_cnn_accelerator_WriteReg(InstancePtr->Control_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_ADDR_GIE, 1);
}

void XFashion_mnist_cnn_accelerator_InterruptGlobalDisable(XFashion_mnist_cnn_accelerator *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFashion_mnist_cnn_accelerator_WriteReg(InstancePtr->Control_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_ADDR_GIE, 0);
}

void XFashion_mnist_cnn_accelerator_InterruptEnable(XFashion_mnist_cnn_accelerator *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XFashion_mnist_cnn_accelerator_ReadReg(InstancePtr->Control_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_ADDR_IER);
    XFashion_mnist_cnn_accelerator_WriteReg(InstancePtr->Control_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_ADDR_IER, Register | Mask);
}

void XFashion_mnist_cnn_accelerator_InterruptDisable(XFashion_mnist_cnn_accelerator *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XFashion_mnist_cnn_accelerator_ReadReg(InstancePtr->Control_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_ADDR_IER);
    XFashion_mnist_cnn_accelerator_WriteReg(InstancePtr->Control_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_ADDR_IER, Register & (~Mask));
}

void XFashion_mnist_cnn_accelerator_InterruptClear(XFashion_mnist_cnn_accelerator *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFashion_mnist_cnn_accelerator_WriteReg(InstancePtr->Control_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_ADDR_ISR, Mask);
}

u32 XFashion_mnist_cnn_accelerator_InterruptGetEnabled(XFashion_mnist_cnn_accelerator *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XFashion_mnist_cnn_accelerator_ReadReg(InstancePtr->Control_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_ADDR_IER);
}

u32 XFashion_mnist_cnn_accelerator_InterruptGetStatus(XFashion_mnist_cnn_accelerator *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XFashion_mnist_cnn_accelerator_ReadReg(InstancePtr->Control_BaseAddress, XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_ADDR_ISR);
}

