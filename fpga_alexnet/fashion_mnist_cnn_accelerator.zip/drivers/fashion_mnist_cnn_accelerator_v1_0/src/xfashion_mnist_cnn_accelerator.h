// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.2.2 (64-bit)
// Tool Version Limit: 2024.02
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XFASHION_MNIST_CNN_ACCELERATOR_H
#define XFASHION_MNIST_CNN_ACCELERATOR_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xfashion_mnist_cnn_accelerator_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_r_BaseAddress;
    u64 Control_BaseAddress;
} XFashion_mnist_cnn_accelerator_Config;
#endif

typedef struct {
    u64 Control_r_BaseAddress;
    u64 Control_BaseAddress;
    u32 IsReady;
} XFashion_mnist_cnn_accelerator;

typedef u32 word_type;

typedef struct {
    u32 word_0;
    u32 word_1;
    u32 word_2;
    u32 word_3;
    u32 word_4;
    u32 word_5;
    u32 word_6;
    u32 word_7;
    u32 word_8;
} XFashion_mnist_cnn_accelerator_Layer_config;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XFashion_mnist_cnn_accelerator_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XFashion_mnist_cnn_accelerator_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XFashion_mnist_cnn_accelerator_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XFashion_mnist_cnn_accelerator_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XFashion_mnist_cnn_accelerator_Initialize(XFashion_mnist_cnn_accelerator *InstancePtr, UINTPTR BaseAddress);
XFashion_mnist_cnn_accelerator_Config* XFashion_mnist_cnn_accelerator_LookupConfig(UINTPTR BaseAddress);
#else
int XFashion_mnist_cnn_accelerator_Initialize(XFashion_mnist_cnn_accelerator *InstancePtr, u16 DeviceId);
XFashion_mnist_cnn_accelerator_Config* XFashion_mnist_cnn_accelerator_LookupConfig(u16 DeviceId);
#endif
int XFashion_mnist_cnn_accelerator_CfgInitialize(XFashion_mnist_cnn_accelerator *InstancePtr, XFashion_mnist_cnn_accelerator_Config *ConfigPtr);
#else
int XFashion_mnist_cnn_accelerator_Initialize(XFashion_mnist_cnn_accelerator *InstancePtr, const char* InstanceName);
int XFashion_mnist_cnn_accelerator_Release(XFashion_mnist_cnn_accelerator *InstancePtr);
#endif

void XFashion_mnist_cnn_accelerator_Start(XFashion_mnist_cnn_accelerator *InstancePtr);
u32 XFashion_mnist_cnn_accelerator_IsDone(XFashion_mnist_cnn_accelerator *InstancePtr);
u32 XFashion_mnist_cnn_accelerator_IsIdle(XFashion_mnist_cnn_accelerator *InstancePtr);
u32 XFashion_mnist_cnn_accelerator_IsReady(XFashion_mnist_cnn_accelerator *InstancePtr);
void XFashion_mnist_cnn_accelerator_EnableAutoRestart(XFashion_mnist_cnn_accelerator *InstancePtr);
void XFashion_mnist_cnn_accelerator_DisableAutoRestart(XFashion_mnist_cnn_accelerator *InstancePtr);

void XFashion_mnist_cnn_accelerator_Set_input_ddr(XFashion_mnist_cnn_accelerator *InstancePtr, u64 Data);
u64 XFashion_mnist_cnn_accelerator_Get_input_ddr(XFashion_mnist_cnn_accelerator *InstancePtr);
void XFashion_mnist_cnn_accelerator_Set_output_ddr(XFashion_mnist_cnn_accelerator *InstancePtr, u64 Data);
u64 XFashion_mnist_cnn_accelerator_Get_output_ddr(XFashion_mnist_cnn_accelerator *InstancePtr);
void XFashion_mnist_cnn_accelerator_Set_weights_ddr(XFashion_mnist_cnn_accelerator *InstancePtr, u64 Data);
u64 XFashion_mnist_cnn_accelerator_Get_weights_ddr(XFashion_mnist_cnn_accelerator *InstancePtr);
void XFashion_mnist_cnn_accelerator_Set_bias_ddr(XFashion_mnist_cnn_accelerator *InstancePtr, u64 Data);
u64 XFashion_mnist_cnn_accelerator_Get_bias_ddr(XFashion_mnist_cnn_accelerator *InstancePtr);
void XFashion_mnist_cnn_accelerator_Set_layer_config(XFashion_mnist_cnn_accelerator *InstancePtr, XFashion_mnist_cnn_accelerator_Layer_config Data);
XFashion_mnist_cnn_accelerator_Layer_config XFashion_mnist_cnn_accelerator_Get_layer_config(XFashion_mnist_cnn_accelerator *InstancePtr);
void XFashion_mnist_cnn_accelerator_Set_layer_idx(XFashion_mnist_cnn_accelerator *InstancePtr, u32 Data);
u32 XFashion_mnist_cnn_accelerator_Get_layer_idx(XFashion_mnist_cnn_accelerator *InstancePtr);

void XFashion_mnist_cnn_accelerator_InterruptGlobalEnable(XFashion_mnist_cnn_accelerator *InstancePtr);
void XFashion_mnist_cnn_accelerator_InterruptGlobalDisable(XFashion_mnist_cnn_accelerator *InstancePtr);
void XFashion_mnist_cnn_accelerator_InterruptEnable(XFashion_mnist_cnn_accelerator *InstancePtr, u32 Mask);
void XFashion_mnist_cnn_accelerator_InterruptDisable(XFashion_mnist_cnn_accelerator *InstancePtr, u32 Mask);
void XFashion_mnist_cnn_accelerator_InterruptClear(XFashion_mnist_cnn_accelerator *InstancePtr, u32 Mask);
u32 XFashion_mnist_cnn_accelerator_InterruptGetEnabled(XFashion_mnist_cnn_accelerator *InstancePtr);
u32 XFashion_mnist_cnn_accelerator_InterruptGetStatus(XFashion_mnist_cnn_accelerator *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
