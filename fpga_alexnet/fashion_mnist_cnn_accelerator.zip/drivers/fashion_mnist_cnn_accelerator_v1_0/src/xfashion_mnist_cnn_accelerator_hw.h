// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.2.2 (64-bit)
// Tool Version Limit: 2024.02
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
// control_r
// 0x00 : reserved
// 0x04 : reserved
// 0x08 : reserved
// 0x0c : reserved
// 0x10 : Data signal of input_ddr
//        bit 31~0 - input_ddr[31:0] (Read/Write)
// 0x14 : Data signal of input_ddr
//        bit 31~0 - input_ddr[63:32] (Read/Write)
// 0x18 : reserved
// 0x1c : Data signal of output_ddr
//        bit 31~0 - output_ddr[31:0] (Read/Write)
// 0x20 : Data signal of output_ddr
//        bit 31~0 - output_ddr[63:32] (Read/Write)
// 0x24 : reserved
// 0x28 : Data signal of weights_ddr
//        bit 31~0 - weights_ddr[31:0] (Read/Write)
// 0x2c : Data signal of weights_ddr
//        bit 31~0 - weights_ddr[63:32] (Read/Write)
// 0x30 : reserved
// 0x34 : Data signal of bias_ddr
//        bit 31~0 - bias_ddr[31:0] (Read/Write)
// 0x38 : Data signal of bias_ddr
//        bit 31~0 - bias_ddr[63:32] (Read/Write)
// 0x3c : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_R_ADDR_INPUT_DDR_DATA   0x10
#define XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_R_BITS_INPUT_DDR_DATA   64
#define XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_R_ADDR_OUTPUT_DDR_DATA  0x1c
#define XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_R_BITS_OUTPUT_DDR_DATA  64
#define XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_R_ADDR_WEIGHTS_DDR_DATA 0x28
#define XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_R_BITS_WEIGHTS_DDR_DATA 64
#define XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_R_ADDR_BIAS_DDR_DATA    0x34
#define XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_R_BITS_BIAS_DDR_DATA    64

// CONTROL
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read/COR)
//        bit 7  - auto_restart (Read/Write)
//        bit 9  - interrupt (Read)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0 - enable ap_done interrupt (Read/Write)
//        bit 1 - enable ap_ready interrupt (Read/Write)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0 - ap_done (Read/TOW)
//        bit 1 - ap_ready (Read/TOW)
//        others - reserved
// 0x10 : Data signal of layer_config
//        bit 31~0 - layer_config[31:0] (Read/Write)
// 0x14 : Data signal of layer_config
//        bit 31~0 - layer_config[63:32] (Read/Write)
// 0x18 : Data signal of layer_config
//        bit 31~0 - layer_config[95:64] (Read/Write)
// 0x1c : Data signal of layer_config
//        bit 31~0 - layer_config[127:96] (Read/Write)
// 0x20 : Data signal of layer_config
//        bit 31~0 - layer_config[159:128] (Read/Write)
// 0x24 : Data signal of layer_config
//        bit 31~0 - layer_config[191:160] (Read/Write)
// 0x28 : Data signal of layer_config
//        bit 31~0 - layer_config[223:192] (Read/Write)
// 0x2c : Data signal of layer_config
//        bit 31~0 - layer_config[255:224] (Read/Write)
// 0x30 : Data signal of layer_config
//        bit 31~0 - layer_config[287:256] (Read/Write)
// 0x34 : reserved
// 0x38 : Data signal of layer_idx
//        bit 31~0 - layer_idx[31:0] (Read/Write)
// 0x3c : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_ADDR_AP_CTRL           0x00
#define XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_ADDR_GIE               0x04
#define XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_ADDR_IER               0x08
#define XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_ADDR_ISR               0x0c
#define XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_ADDR_LAYER_CONFIG_DATA 0x10
#define XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_BITS_LAYER_CONFIG_DATA 288
#define XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_ADDR_LAYER_IDX_DATA    0x38
#define XFASHION_MNIST_CNN_ACCELERATOR_CONTROL_BITS_LAYER_IDX_DATA    32

