// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.2.2 (64-bit)
// Tool Version Limit: 2024.02
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xfashion_mnist_cnn_accelerator.h"

extern XFashion_mnist_cnn_accelerator_Config XFashion_mnist_cnn_accelerator_ConfigTable[];

#ifdef SDT
XFashion_mnist_cnn_accelerator_Config *XFashion_mnist_cnn_accelerator_LookupConfig(UINTPTR BaseAddress) {
	XFashion_mnist_cnn_accelerator_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XFashion_mnist_cnn_accelerator_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XFashion_mnist_cnn_accelerator_ConfigTable[Index].Control_r_BaseAddress == BaseAddress) {
			ConfigPtr = &XFashion_mnist_cnn_accelerator_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XFashion_mnist_cnn_accelerator_Initialize(XFashion_mnist_cnn_accelerator *InstancePtr, UINTPTR BaseAddress) {
	XFashion_mnist_cnn_accelerator_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XFashion_mnist_cnn_accelerator_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XFashion_mnist_cnn_accelerator_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XFashion_mnist_cnn_accelerator_Config *XFashion_mnist_cnn_accelerator_LookupConfig(u16 DeviceId) {
	XFashion_mnist_cnn_accelerator_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XFASHION_MNIST_CNN_ACCELERATOR_NUM_INSTANCES; Index++) {
		if (XFashion_mnist_cnn_accelerator_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XFashion_mnist_cnn_accelerator_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XFashion_mnist_cnn_accelerator_Initialize(XFashion_mnist_cnn_accelerator *InstancePtr, u16 DeviceId) {
	XFashion_mnist_cnn_accelerator_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XFashion_mnist_cnn_accelerator_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XFashion_mnist_cnn_accelerator_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

