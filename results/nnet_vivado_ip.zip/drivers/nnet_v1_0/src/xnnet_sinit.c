// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.2.2 (64-bit)
// Tool Version Limit: 2024.02
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xnnet.h"

extern XNnet_Config XNnet_ConfigTable[];

#ifdef SDT
XNnet_Config *XNnet_LookupConfig(UINTPTR BaseAddress) {
	XNnet_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XNnet_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XNnet_ConfigTable[Index].Control_r_BaseAddress == BaseAddress) {
			ConfigPtr = &XNnet_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XNnet_Initialize(XNnet *InstancePtr, UINTPTR BaseAddress) {
	XNnet_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XNnet_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XNnet_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XNnet_Config *XNnet_LookupConfig(u16 DeviceId) {
	XNnet_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XNNET_NUM_INSTANCES; Index++) {
		if (XNnet_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XNnet_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XNnet_Initialize(XNnet *InstancePtr, u16 DeviceId) {
	XNnet_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XNnet_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XNnet_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

